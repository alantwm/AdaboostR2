This is the java code implementing the Two-Stage TrAdaBoost.R2 algorithm from the paper "Boosting for Regression Transfer" using the WEKA machine learning toolkit. It is a slightly cleaned up version of the code from its state when I finished grad school, so I apologize if it is messy, and it is likely not self explanatory. There's one main problem, which is that this version doesn't include the cross validation to determine the number of iterations as described in the paper. Instead, it outputs the actual RMS error of the model for each first-stage iteration on the test set passed to it with the -TT parameter. I used a script to perform cross validation using this output and then run the algorithm again with the optimal number of first-stage iterations, but I have not included it as it was pretty specific to my old department's machine cluster (and very messy). Also, there's a lot of extra code here that implements variations not mentioned in the paper if certain flags are set.

You can run a test on the included files (from the Friedman #1 data set described in the paper) as follows:
$java -cp weka.jar:. TwoStageTrAdaBoostR2 -W weka.classifiers.trees.M5P -M -R -Ratio -1 -S source.arff -t train.arff -T test.arff -TT test.arff -v -o -I 10 -II 10
This will use M5P trees as the base learner and use 10 iterations for both stage 1 and stage 2. Aside from the number of iterations being 10 instead of 30, this combination of flags should match what is described in the paper. The output should look something like:

Iteration -1:5.136706153797207
Iteration 0:4.530421767595497
Iteration 1:4.273636527518781
Iteration 2:3.967956096716119
Iteration 3:3.2302972071851
Iteration 4:3.1399356849661384
Iteration 5:2.91658635001737
Iteration 6:2.922464152829164
Iteration 7:2.886091984774022
Iteration 8:3.2148548420610927
Iteration 9:3.4806299156081297

You can ignore the standard weka output that follows, since it just matches the final iteration.  The meaning of this is that all source and target weights start out equal (iteration -1), then in each stage 1 the total source weight decreases by 10 % until it is essentially 0 in iteration 9.  Here the best results were after iteration 7, when the source instances had a total weight of about 20% of the original.  In other words, steps 2-4 of Algorithm 3 in the paper had been performed 8 times, and then the result of the next step 1 (10 iterations of AdaBoost.R2 with source weights fixed) was a model producing an RMS error of 2.886. Ideally, a previously-performed cross validation step would have identified 7 as the optimal iteration number.

Additional data sets are available here: http://www.cs.utexas.edu/~TacTex/transfer_data.html